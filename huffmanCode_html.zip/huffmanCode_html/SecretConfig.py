PGHOST='ep-red-sun-a20g8yxw.eu-central-1.aws.neon.tech'
PGDATABASE='compresor'
PGUSER='calcukara_owner'
PGPASSWORD='1lRELx0vMSgI'
PGPORT= 5432;

  
